import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Prescription {
  id: string;
  patientId: string;
  doctorId: string;
  doctorName: string;
  date: string;
  imageUrl: string;
}

interface PrescriptionContextType {
  prescriptions: Prescription[];
  addPrescription: (prescription: Omit<Prescription, 'id'>) => void;
}

const PrescriptionContext = createContext<PrescriptionContextType | null>(null);

export const PrescriptionProvider = ({ children }: { children: ReactNode }) => {
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);

  const addPrescription = (prescription: Omit<Prescription, 'id'>) => {
    setPrescriptions([...prescriptions, { ...prescription, id: Math.random().toString() }]);
  };

  return (
    <PrescriptionContext.Provider value={{ prescriptions, addPrescription }}>
      {children}
    </PrescriptionContext.Provider>
  );
};

export const usePrescriptions = () => {
  const context = useContext(PrescriptionContext);
  if (!context) {
    throw new Error('usePrescriptions must be used within a PrescriptionProvider');
  }
  return context;
};