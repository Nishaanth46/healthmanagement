import React, { createContext, useContext, useState, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  role: 'doctor' | 'patient';
  name: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: 'doctor' | 'patient') => void;
  logout: () => void;
  register: (email: string, password: string, role: 'doctor' | 'patient', name: string) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = (email: string, password: string, role: 'doctor' | 'patient') => {
    // Simulate authentication
    setUser({ id: Math.random().toString(), email, role, name: email.split('@')[0] });
  };

  const logout = () => {
    setUser(null);
  };

  const register = (email: string, password: string, role: 'doctor' | 'patient', name: string) => {
    // Simulate registration
    setUser({ id: Math.random().toString(), email, role, name });
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};