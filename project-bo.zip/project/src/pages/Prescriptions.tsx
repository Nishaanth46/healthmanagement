import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { usePrescriptions } from '../context/PrescriptionContext';
import { Upload, Check } from 'lucide-react';

export default function Prescriptions() {
  const { user } = useAuth();
  const { prescriptions, addPrescription } = usePrescriptions();
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImage(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const handleSubmit = () => {
    if (selectedImage && user) {
      // In a real app, you would upload the image to a server
      // Here we're just using the preview URL
      addPrescription({
        patientId: user.id,
        doctorId: 'doctor-id', // In a real app, this would be the actual doctor's ID
        doctorName: 'Dr. Smith', // In a real app, this would be the actual doctor's name
        date: new Date().toISOString(),
        imageUrl: previewUrl || '',
      });
      setSelectedImage(null);
      setPreviewUrl(null);
      setShowHistory(true);
    }
  };

  const userPrescriptions = prescriptions.filter(
    prescription => user?.role === 'patient' 
      ? prescription.patientId === user.id 
      : prescription.doctorId === user.id
  );

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Prescriptions Management</h2>
      
      {user?.role === 'patient' && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h3 className="text-xl font-semibold mb-4">Upload New Prescription</h3>
          <div className="space-y-4">
            <div 
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500"
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleImageChange}
              />
              <Upload className="mx-auto h-12 w-12 text-gray-400 mb-2" />
              <p className="text-gray-600">Click to upload prescription image</p>
            </div>

            {previewUrl && (
              <div className="mt-4">
                <img
                  src={previewUrl}
                  alt="Prescription preview"
                  className="max-w-full h-auto rounded-lg"
                />
                <button
                  onClick={handleSubmit}
                  className="mt-4 w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center justify-center"
                >
                  <Check className="h-5 w-5 mr-2" />
                  Submit Prescription
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Prescription History</h3>
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="text-blue-600 hover:text-blue-700"
          >
            {showHistory ? 'Hide History' : 'Show History'}
          </button>
        </div>

        {showHistory && (
          <div className="space-y-4">
            {userPrescriptions.length === 0 ? (
              <p className="text-gray-600 text-center py-4">No prescriptions found.</p>
            ) : (
              userPrescriptions.map((prescription) => (
                <div
                  key={prescription.id}
                  className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">Doctor: {prescription.doctorName}</span>
                    <span className="text-gray-600">
                      {new Date(prescription.date).toLocaleDateString()}
                    </span>
                  </div>
                  <img
                    src={prescription.imageUrl}
                    alt="Prescription"
                    className="w-full h-auto rounded-lg mt-2"
                  />
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}