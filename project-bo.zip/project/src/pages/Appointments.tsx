import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useAppointments } from '../context/AppointmentContext';
import { Calendar, Clock, User, CheckCircle, XCircle } from 'lucide-react';

const DOCTORS = [
  { id: 'doc1', name: 'Dr. Sarah Johnson', specialization: 'Cardiologist' },
  { id: 'doc2', name: 'Dr. Michael Chen', specialization: 'Dermatologist' },
  { id: 'doc3', name: 'Dr. Emily Brown', specialization: 'Pediatrician' },
  { id: 'doc4', name: 'Dr. James Wilson', specialization: 'Neurologist' },
];

export default function Appointments() {
  const { user } = useAuth();
  const { appointments, addAppointment, updateAppointmentStatus } = useAppointments();
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (user && selectedDoctor) {
      const doctor = DOCTORS.find(doc => doc.id === selectedDoctor);
      if (doctor) {
        addAppointment({
          doctorId: doctor.id,
          doctorName: doctor.name,
          patientId: user.id,
          patientName: user.name,
          date,
          time,
        });
      }
      // Reset form
      setSelectedDoctor('');
      setDate('');
      setTime('');
    }
  };

  const userAppointments = appointments.filter(
    appointment => user?.role === 'patient' 
      ? appointment.patientId === user.id 
      : appointment.doctorId === user.id
  );

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Appointments</h2>

      {user?.role === 'patient' && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h3 className="text-xl font-semibold mb-4">Book New Appointment</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Doctor
              </label>
              <select
                value={selectedDoctor}
                onChange={(e) => setSelectedDoctor(e.target.value)}
                className="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="">Choose a doctor</option>
                {DOCTORS.map((doctor) => (
                  <option key={doctor.id} value={doctor.id}>
                    {doctor.name} - {doctor.specialization}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Time
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full p-2 border rounded-md focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
            >
              Book Appointment
            </button>
          </form>
        </div>
      )}

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-xl font-semibold mb-4">
          {user?.role === 'patient' ? 'Your Appointments' : 'Patient Appointments'}
        </h3>
        <div className="space-y-4">
          {userAppointments.length === 0 ? (
            <p className="text-gray-600 text-center py-4">No appointments found.</p>
          ) : (
            userAppointments.map((appointment) => (
              <div
                key={appointment.id}
                className="border rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex flex-wrap justify-between items-start gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <User className="h-5 w-5 text-gray-500" />
                      <span className="font-medium">
                        {user?.role === 'patient' 
                          ? `Dr. ${appointment.doctorName}`
                          : appointment.patientName}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-5 w-5 text-gray-500" />
                      <span>{appointment.date}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-5 w-5 text-gray-500" />
                      <span>{appointment.time}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {user?.role === 'doctor' && appointment.status === 'pending' ? (
                      <>
                        <button
                          onClick={() => updateAppointmentStatus(appointment.id, 'accepted')}
                          className="flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200"
                        >
                          <CheckCircle className="h-4 w-4" />
                          <span>Accept</span>
                        </button>
                        <button
                          onClick={() => updateAppointmentStatus(appointment.id, 'rejected')}
                          className="flex items-center space-x-1 px-3 py-1 bg-red-100 text-red-700 rounded-md hover:bg-red-200"
                        >
                          <XCircle className="h-4 w-4" />
                          <span>Reject</span>
                        </button>
                      </>
                    ) : (
                      <span
                        className={`px-3 py-1 rounded-md ${
                          appointment.status === 'accepted'
                            ? 'bg-green-100 text-green-700'
                            : appointment.status === 'rejected'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-yellow-100 text-yellow-700'
                        }`}
                      >
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}