import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Heart, Stethoscope, Pill, Calendar } from 'lucide-react';

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">HealthCare Plus</span>
            </div>
            <div className="flex items-center">
              {user ? (
                <Link
                  to="/dashboard"
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                >
                  Dashboard
                </Link>
              ) : (
                <div className="space-x-4">
                  <Link
                    to="/login"
                    className="text-gray-600 hover:text-blue-600"
                  >
                    Login
                  </Link>
                  <Link
                    to="/register"
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                  >
                    Register
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Your Health, Our Priority
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Comprehensive healthcare management at your fingertips
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-12">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Stethoscope className="h-12 w-12 text-blue-600 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Online Consultations</h2>
            <p className="text-gray-600">
              Book appointments with qualified doctors from the comfort of your home
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <Calendar className="h-12 w-12 text-blue-600 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Easy Scheduling</h2>
            <p className="text-gray-600">
              Manage your appointments and prescriptions efficiently
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <Pill className="h-12 w-12 text-blue-600 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Online Pharmacy</h2>
            <p className="text-gray-600">
              Order medicines online with valid prescriptions
            </p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <img
            src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80"
            alt="Healthcare professionals"
            className="rounded-lg shadow-xl mx-auto"
          />
        </div>
      </main>
    </div>
  );
}