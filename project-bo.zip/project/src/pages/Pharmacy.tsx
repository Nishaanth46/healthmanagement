import React from 'react';
import { ShoppingBag, Plus } from 'lucide-react';
import { usePrescriptions } from '../context/PrescriptionContext';
import { useAuth } from '../context/AuthContext';

const MEDICINES = [
  {
    id: 'med1',
    name: 'Amoxicillin',
    description: 'Antibiotic for bacterial infections',
    price: 15.99,
    requiresPrescription: true,
  },
  {
    id: 'med2',
    name: 'Ibuprofen',
    description: 'Pain reliever and fever reducer',
    price: 8.99,
    requiresPrescription: false,
  },
  {
    id: 'med3',
    name: 'Omeprazole',
    description: 'Reduces stomach acid production',
    price: 12.99,
    requiresPrescription: true,
  },
  {
    id: 'med4',
    name: 'Cetirizine',
    description: 'Antihistamine for allergies',
    price: 9.99,
    requiresPrescription: false,
  },
  {
    id: 'med5',
    name: 'Metformin',
    description: 'Diabetes medication',
    price: 19.99,
    requiresPrescription: true,
  },
];

export default function Pharmacy() {
  const { prescriptions } = usePrescriptions();
  const { user } = useAuth();
  const hasPrescription = prescriptions.some(p => p.patientId === user?.id);

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Pharmacy</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MEDICINES.map((medicine) => (
          <div
            key={medicine.id}
            className="bg-white rounded-lg shadow-md overflow-hidden"
          >
            <div className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {medicine.name}
                  </h3>
                  <p className="mt-1 text-gray-600">{medicine.description}</p>
                </div>
                <ShoppingBag className="h-6 w-6 text-blue-600" />
              </div>
              <div className="mt-4">
                <span className="text-2xl font-bold text-gray-900">
                  ${medicine.price}
                </span>
              </div>
              <div className="mt-4">
                {medicine.requiresPrescription ? (
                  <div className="text-sm text-orange-600 mb-2">
                    Requires prescription
                  </div>
                ) : (
                  <div className="text-sm text-green-600 mb-2">
                    No prescription needed
                  </div>
                )}
                <button
                  className={`w-full flex items-center justify-center px-4 py-2 rounded-md ${
                    medicine.requiresPrescription && !hasPrescription
                      ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                  disabled={medicine.requiresPrescription && !hasPrescription}
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {!hasPrescription && (
        <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-yellow-700">
            Some medicines require a valid prescription. Please upload your prescription in the Prescriptions section to purchase prescription medicines.
          </p>
        </div>
      )}
    </div>
  );
}