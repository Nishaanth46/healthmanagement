import React, { useState } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Menu, X, Heart, Calendar, FileText, ShoppingBag } from 'lucide-react';
import Appointments from './Appointments';
import Prescriptions from './Prescriptions';
import Pharmacy from './Pharmacy';

export default function Dashboard() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">HealthCare Plus</span>
            </div>
            <div className="flex items-center">
              <button
                onClick={() => setIsDrawerOpen(!isDrawerOpen)}
                className="md:hidden p-2"
              >
                {isDrawerOpen ? <X /> : <Menu />}
              </button>
              <div className="hidden md:flex items-center space-x-4">
                <span className="text-gray-700">Welcome, {user?.name}</span>
                <button
                  onClick={handleLogout}
                  className="text-red-600 hover:text-red-700"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Drawer */}
      <div className="flex">
        <div
          className={`${
            isDrawerOpen ? 'translate-x-0' : '-translate-x-full'
          } md:translate-x-0 fixed md:static inset-y-0 left-0 transform transition duration-200 ease-in-out z-30 w-64 bg-white shadow-lg md:shadow-none`}
        >
          <div className="p-6 space-y-4">
            <div className="md:hidden mb-8">
              <span className="text-gray-700">Welcome, {user?.name}</span>
              <button
                onClick={handleLogout}
                className="mt-2 text-red-600 hover:text-red-700 block"
              >
                Logout
              </button>
            </div>
            <Link
              to="appointments"
              className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 p-2 rounded-lg hover:bg-blue-50"
            >
              <Calendar className="h-5 w-5" />
              <span>Appointments</span>
            </Link>
            <Link
              to="prescriptions"
              className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 p-2 rounded-lg hover:bg-blue-50"
            >
              <FileText className="h-5 w-5" />
              <span>Prescriptions</span>
            </Link>
            <Link
              to="pharmacy"
              className="flex items-center space-x-2 text-gray-700 hover:text-blue-600 p-2 rounded-lg hover:bg-blue-50"
            >
              <ShoppingBag className="h-5 w-5" />
              <span>Pharmacy</span>
            </Link>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          <Routes>
            <Route path="appointments" element={<Appointments />} />
            <Route path="prescriptions" element={<Prescriptions />} />
            <Route path="pharmacy" element={<Pharmacy />} />
            <Route path="/" element={<Appointments />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}